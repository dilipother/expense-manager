import 'package:intl/intl.dart';

class Formatters {
  Formatters._();

  static final _currency = NumberFormat.currency(
    symbol: '₹',
    decimalDigits: 2,
    locale: 'en_IN',
  );

  static final _currencyCompact = NumberFormat.currency(
    symbol: '₹',
    decimalDigits: 0,
    locale: 'en_IN',
  );

  static final _dateShort = DateFormat('dd MMM');
  static final _dateFull = DateFormat('dd MMM yyyy');
  static final _dateTime = DateFormat('dd MMM yyyy, hh:mm a');
  static final _monthYear = DateFormat('MMMM yyyy');
  static final _time = DateFormat('hh:mm a');

  /// ₹1,23,456.78
  static String currency(double amount) => _currency.format(amount);

  /// ₹1,23,456  (no decimals)
  static String currencyCompact(double amount) => _currencyCompact.format(amount);

  /// Signed: +₹500 or -₹500
  static String signedCurrency(double amount, {bool isIncome = false}) {
    final sign = isIncome ? '+' : '-';
    return '$sign${_currencyCompact.format(amount.abs())}';
  }

  /// 25 Mar
  static String dateShort(DateTime d) => _dateShort.format(d);

  /// 25 Mar 2026
  static String dateFull(DateTime d) => _dateFull.format(d);

  /// 25 Mar 2026, 03:45 PM
  static String dateTime(DateTime d) => _dateTime.format(d);

  /// March 2026
  static String monthYear(DateTime d) => _monthYear.format(d);

  /// 03:45 PM
  static String time(DateTime d) => _time.format(d);

  /// Relative: "Today", "Yesterday", "3 days ago", "25 Mar"
  static String relative(DateTime d) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final target = DateTime(d.year, d.month, d.day);
    final diff = today.difference(target).inDays;

    if (diff == 0) return 'Today';
    if (diff == 1) return 'Yesterday';
    if (diff < 7) return '$diff days ago';
    return dateShort(d);
  }

  /// Compact large numbers: 1.2L, 45K, 1.5Cr
  static String compactINR(double amount) {
    if (amount >= 10000000) return '₹${(amount / 10000000).toStringAsFixed(1)}Cr';
    if (amount >= 100000) return '₹${(amount / 100000).toStringAsFixed(1)}L';
    if (amount >= 1000) return '₹${(amount / 1000).toStringAsFixed(1)}K';
    return currencyCompact(amount);
  }

  /// Percentage with 1 decimal: 45.3%
  static String percent(double value, {int decimals = 1}) =>
      '${value.toStringAsFixed(decimals)}%';
}
