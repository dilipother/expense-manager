import 'package:flutter/material.dart';

class AppTheme {
  static const Color primary = Color(0xFF6C63FF);
  static const Color secondary = Color(0xFFFF6584);
  static const Color accent = Color(0xFF43B89C);
  static const Color orange = Color(0xFFFF9F43);
  static const Color background = Color(0xFFF5F6FA);
  static const Color cardBg = Colors.white;
  static const Color textDark = Color(0xFF2D3436);
  static const Color textGrey = Color(0xFF636E72);
  static const Color income = Color(0xFF00B894);
  static const Color expense = Color(0xFFFF6584);
  static const Color cashColor = Color(0xFFFF9F43);

  static ThemeData get theme => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: primary,
          background: background,
        ),
        scaffoldBackgroundColor: background,
        appBarTheme: const AppBarTheme(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
        ),
        cardTheme: CardThemeData(
          color: cardBg,
          elevation: 4,
          shadowColor: Colors.black12,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primary,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: primary, width: 2),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
        fontFamily: 'SF Pro Display',
      );
}

class AppConstants {
  static const Map<String, IconData> categoryIcons = {
    'Food & Dining': Icons.restaurant,
    'Shopping': Icons.shopping_bag,
    'Transport': Icons.directions_car,
    'Bills & Utilities': Icons.receipt_long,
    'Entertainment': Icons.movie,
    'Health & Fitness': Icons.favorite,
    'Travel': Icons.flight,
    'Education': Icons.school,
    'Personal Care': Icons.spa,
    'Salary': Icons.account_balance_wallet,
    'Freelance': Icons.work,
    'Investment': Icons.trending_up,
    'Gift': Icons.card_giftcard,
    'Rental': Icons.home,
    'Business': Icons.business,
    'Others': Icons.more_horiz,
  };

  static const Map<String, Color> categoryColors = {
    'Food & Dining': Color(0xFFFF6584),
    'Shopping': Color(0xFF6C63FF),
    'Transport': Color(0xFF43B89C),
    'Bills & Utilities': Color(0xFFFF9F43),
    'Entertainment': Color(0xFFE056FD),
    'Health & Fitness': Color(0xFF00B894),
    'Travel': Color(0xFF0984E3),
    'Education': Color(0xFFFD9644),
    'Personal Care': Color(0xFFFF6B81),
    'Salary': Color(0xFF00B894),
    'Freelance': Color(0xFF6C63FF),
    'Investment': Color(0xFF43B89C),
    'Gift': Color(0xFFFF6584),
    'Rental': Color(0xFF0984E3),
    'Business': Color(0xFFFF9F43),
    'Others': Color(0xFF636E72),
  };
}
