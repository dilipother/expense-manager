import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/transaction_model.dart';
import '../models/bank_account_model.dart';
import '../models/cash_model.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('expense_manager.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE bank_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bankName TEXT NOT NULL,
        accountNumber TEXT NOT NULL,
        accountType TEXT NOT NULL,
        balance REAL NOT NULL DEFAULT 0,
        color INTEGER NOT NULL,
        createdAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        amount REAL NOT NULL,
        type TEXT NOT NULL,
        category TEXT NOT NULL,
        accountId INTEGER,
        isCash INTEGER NOT NULL DEFAULT 0,
        note TEXT,
        date TEXT NOT NULL,
        smsSource TEXT,
        merchantName TEXT,
        createdAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE cash_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        description TEXT,
        date TEXT NOT NULL,
        createdAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE sms_processed (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        smsId TEXT UNIQUE,
        processedAt TEXT NOT NULL
      )
    ''');

    // Insert sample bank accounts
    await db.insert('bank_accounts', {
      'bankName': 'HDFC Bank',
      'accountNumber': 'XXXX1234',
      'accountType': 'Savings',
      'balance': 45230.50,
      'color': 0xFF6C63FF,
      'createdAt': DateTime.now().toIso8601String(),
    });

    await db.insert('bank_accounts', {
      'bankName': 'ICICI Bank',
      'accountNumber': 'XXXX5678',
      'accountType': 'Current',
      'balance': 12800.00,
      'color': 0xFFFF6584,
      'createdAt': DateTime.now().toIso8601String(),
    });

    await db.insert('bank_accounts', {
      'bankName': 'SBI Credit Card',
      'accountNumber': 'XXXX9012',
      'accountType': 'Credit Card',
      'balance': -8500.00,
      'color': 0xFF43B89C,
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  // ---- Bank Accounts ----
  Future<List<BankAccount>> getBankAccounts() async {
    final db = await database;
    final maps = await db.query('bank_accounts', orderBy: 'createdAt DESC');
    return maps.map((e) => BankAccount.fromMap(e)).toList();
  }

  Future<int> insertBankAccount(BankAccount account) async {
    final db = await database;
    return await db.insert('bank_accounts', account.toMap());
  }

  Future<int> updateBankAccount(BankAccount account) async {
    final db = await database;
    return await db.update('bank_accounts', account.toMap(), where: 'id = ?', whereArgs: [account.id]);
  }

  Future<int> deleteBankAccount(int id) async {
    final db = await database;
    return await db.delete('bank_accounts', where: 'id = ?', whereArgs: [id]);
  }

  // ---- Transactions ----
  Future<List<ExpenseTransaction>> getTransactions({int? accountId, bool? isCash}) async {
    final db = await database;
    String? where;
    List<dynamic>? args;
    if (accountId != null) {
      where = 'accountId = ?';
      args = [accountId];
    } else if (isCash == true) {
      where = 'isCash = 1';
    }
    final maps = await db.query('transactions', where: where, whereArgs: args, orderBy: 'date DESC');
    return maps.map((e) => ExpenseTransaction.fromMap(e)).toList();
  }

  Future<List<ExpenseTransaction>> getAllTransactions() async {
    final db = await database;
    final maps = await db.query('transactions', orderBy: 'date DESC');
    return maps.map((e) => ExpenseTransaction.fromMap(e)).toList();
  }

  Future<int> insertTransaction(ExpenseTransaction txn) async {
    final db = await database;
    final id = await db.insert('transactions', txn.toMap());
    // Update balance
    if (txn.accountId != null) {
      final accounts = await db.query('bank_accounts', where: 'id = ?', whereArgs: [txn.accountId]);
      if (accounts.isNotEmpty) {
        double balance = (accounts.first['balance'] as double);
        if (txn.type == 'income') {
          balance += txn.amount;
        } else {
          balance -= txn.amount;
        }
        await db.update('bank_accounts', {'balance': balance}, where: 'id = ?', whereArgs: [txn.accountId]);
      }
    }
    return id;
  }

  Future<int> deleteTransaction(int id) async {
    final db = await database;
    return await db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }

  // ---- Cash ----
  Future<List<CashEntry>> getCashEntries() async {
    final db = await database;
    final maps = await db.query('cash_entries', orderBy: 'date DESC');
    return maps.map((e) => CashEntry.fromMap(e)).toList();
  }

  Future<double> getCashOnHand() async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(CASE WHEN type="add" OR type="atm_withdraw" THEN amount ELSE -amount END) as total FROM cash_entries');
    return (result.first['total'] as double?) ?? 0.0;
  }

  Future<int> insertCashEntry(CashEntry entry) async {
    final db = await database;
    return await db.insert('cash_entries', entry.toMap());
  }

  // ---- SMS Processed ----
  Future<bool> isSmsProcessed(String smsId) async {
    final db = await database;
    final result = await db.query('sms_processed', where: 'smsId = ?', whereArgs: [smsId]);
    return result.isNotEmpty;
  }

  Future<void> markSmsProcessed(String smsId) async {
    final db = await database;
    await db.insert('sms_processed', {'smsId': smsId, 'processedAt': DateTime.now().toIso8601String()}, conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  // ---- Summary ----
  Future<Map<String, double>> getMonthlySummary() async {
    final db = await database;
    final now = DateTime.now();
    final startOfMonth = DateTime(now.year, now.month, 1).toIso8601String();
    
    final income = await db.rawQuery("SELECT SUM(amount) as total FROM transactions WHERE type='income' AND date >= ?", [startOfMonth]);
    final expense = await db.rawQuery("SELECT SUM(amount) as total FROM transactions WHERE type='expense' AND date >= ?", [startOfMonth]);

    return {
      'income': (income.first['total'] as double?) ?? 0.0,
      'expense': (expense.first['total'] as double?) ?? 0.0,
    };
  }

  Future<List<Map<String, dynamic>>> getCategoryWiseExpense() async {
    final db = await database;
    final now = DateTime.now();
    final startOfMonth = DateTime(now.year, now.month, 1).toIso8601String();
    return await db.rawQuery(
      "SELECT category, SUM(amount) as total FROM transactions WHERE type='expense' AND date >= ? GROUP BY category ORDER BY total DESC",
      [startOfMonth],
    );
  }
}
