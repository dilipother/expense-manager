import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_provider.dart';
import '../models/transaction_model.dart';
import '../utils/app_theme.dart';
import '../utils/validators.dart';

class AddTransactionScreen extends StatefulWidget {
  final bool isCash;
  const AddTransactionScreen({super.key, this.isCash = false});

  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();

  String _selectedCategory = expenseCategories[0];
  int? _selectedAccountId;
  bool _isCash = false;
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _isCash = widget.isCash;
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        setState(() {
          _selectedCategory = _tabController.index == 0 ? expenseCategories[0] : incomeCategories[0];
        });
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _titleCtrl.dispose();
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final type = _tabController.index == 0 ? 'expense' : 'income';
    final txn = ExpenseTransaction(
      title: _titleCtrl.text.trim(),
      amount: double.parse(_amountCtrl.text),
      type: type,
      category: _selectedCategory,
      accountId: _isCash ? null : _selectedAccountId,
      isCash: _isCash,
      note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
      date: _selectedDate,
    );

    await context.read<AppProvider>().addTransaction(txn);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (d != null) setState(() => _selectedDate = d);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Add Transaction'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: Colors.white,
          indicatorWeight: 3,
          tabs: const [
            Tab(text: 'EXPENSE'),
            Tab(text: 'INCOME'),
          ],
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Amount Input
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppTheme.primary, Color(0xFF4A44B5)]),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  const Text('Amount', style: TextStyle(color: Colors.white70, fontSize: 14)),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('₹', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                      IntrinsicWidth(
                        child: TextFormField(
                          controller: _amountCtrl,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          style: const TextStyle(color: Colors.white, fontSize: 40, fontWeight: FontWeight.bold),
                          decoration: const InputDecoration(
                            hintText: '0',
                            hintStyle: TextStyle(color: Colors.white38, fontSize: 40),
                            border: InputBorder.none,
                            filled: false,
                            contentPadding: EdgeInsets.zero,
                          ),
                          validator: Validators.amount,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Title
            TextFormField(
              controller: _titleCtrl,
              decoration: const InputDecoration(
                labelText: 'Title / Description',
                prefixIcon: Icon(Icons.title),
              ),
              validator: (v) => Validators.required(v, 'Title'),
            ),
            const SizedBox(height: 16),

            // Category
            DropdownButtonFormField<String>(
              value: _selectedCategory,
              decoration: const InputDecoration(
                labelText: 'Category',
                prefixIcon: Icon(Icons.category),
              ),
              items: (_tabController.index == 0 ? expenseCategories : incomeCategories)
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: (v) => setState(() => _selectedCategory = v!),
            ),
            const SizedBox(height: 16),

            // Source: Cash or Account
            SwitchListTile(
              title: const Text('Cash Transaction', style: TextStyle(fontWeight: FontWeight.w500)),
              subtitle: const Text('Toggle for cash or bank account'),
              value: _isCash,
              activeColor: AppTheme.orange,
              onChanged: (v) => setState(() => _isCash = v),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: Colors.grey.shade300),
              ),
              tileColor: Colors.white,
            ),
            const SizedBox(height: 16),

            if (!_isCash) ...[
              DropdownButtonFormField<int?>(
                value: _selectedAccountId,
                decoration: const InputDecoration(
                  labelText: 'Bank Account',
                  prefixIcon: Icon(Icons.account_balance),
                ),
                items: [
                  const DropdownMenuItem(value: null, child: Text('Select account')),
                  ...provider.accounts.map((a) => DropdownMenuItem(
                    value: a.id,
                    child: Text('${a.bankName} - ${a.maskedAccount}'),
                  )),
                ],
                onChanged: (v) => setState(() => _selectedAccountId = v),
              ),
              const SizedBox(height: 16),
            ],

            // Date
            GestureDetector(
              onTap: _pickDate,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.calendar_today, color: AppTheme.textGrey, size: 20),
                    const SizedBox(width: 12),
                    Text(DateFormat('dd MMMM, yyyy').format(_selectedDate), style: const TextStyle(fontSize: 16)),
                    const Spacer(),
                    const Icon(Icons.arrow_drop_down, color: AppTheme.textGrey),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Note
            TextFormField(
              controller: _noteCtrl,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Note (optional)',
                prefixIcon: Icon(Icons.note_outlined),
              ),
            ),
            const SizedBox(height: 32),

            ElevatedButton(
              onPressed: _submit,
              style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 52)),
              child: const Text('Save Transaction', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
