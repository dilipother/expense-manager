import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_provider.dart';
import '../utils/app_theme.dart';
import 'budget_screen.dart';
import 'sms_import_screen.dart';
import 'transfer_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _section('Features', [
            _tile(
              icon: Icons.pie_chart,
              color: AppTheme.primary,
              title: 'Budget Tracker',
              subtitle: 'Set monthly limits per category',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BudgetScreen())),
            ),
            _tile(
              icon: Icons.swap_horiz,
              color: AppTheme.accent,
              title: 'Transfer Money',
              subtitle: 'Move funds between accounts',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransferScreen())),
            ),
            _tile(
              icon: Icons.sms,
              color: AppTheme.secondary,
              title: 'SMS Import',
              subtitle: 'Import bank transactions from SMS',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SmsImportScreen())),
            ),
          ]),
          const SizedBox(height: 16),
          _section('App', [
            _tile(
              icon: Icons.color_lens_outlined,
              color: Colors.purple,
              title: 'Theme',
              subtitle: 'Light mode (more coming soon)',
              onTap: () {},
            ),
            _tile(
              icon: Icons.currency_rupee,
              color: Colors.green,
              title: 'Currency',
              subtitle: 'Indian Rupee (₹)',
              onTap: () {},
            ),
            _tile(
              icon: Icons.lock_outline,
              color: Colors.orange,
              title: 'App Lock',
              subtitle: 'Use Face ID / Fingerprint',
              trailing: Switch(
                value: false,
                onChanged: (_) {},
                activeColor: AppTheme.primary,
              ),
            ),
          ]),
          const SizedBox(height: 16),
          _section('Data', [
            _tile(
              icon: Icons.upload_outlined,
              color: AppTheme.primary,
              title: 'Export Data',
              subtitle: 'Export transactions as CSV',
              onTap: () => _exportData(context),
            ),
            _tile(
              icon: Icons.delete_outline,
              color: Colors.red,
              title: 'Clear All Data',
              subtitle: 'Remove all transactions and accounts',
              onTap: () => _confirmClear(context),
            ),
          ]),
          const SizedBox(height: 16),
          _section('About', [
            _tile(icon: Icons.info_outline, color: AppTheme.textGrey, title: 'Version', subtitle: '1.0.0'),
            _tile(icon: Icons.privacy_tip_outlined, color: AppTheme.textGrey, title: 'Privacy Policy', subtitle: 'Your data stays on device'),
          ]),
          const SizedBox(height: 32),
          Center(
            child: Column(
              children: [
                const Icon(Icons.account_balance_wallet, color: AppTheme.primary, size: 36),
                const SizedBox(height: 8),
                const Text('Expense Manager', style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.textDark)),
                Text('Built with Flutter 💙', style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _section(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(title.toUpperCase(), style: TextStyle(color: AppTheme.textGrey, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
          ),
          child: Column(children: children),
        ),
      ],
    );
  }

  Widget _tile({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    VoidCallback? onTap,
    Widget? trailing,
  }) {
    return ListTile(
      onTap: onTap,
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: color, size: 20),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
      subtitle: Text(subtitle, style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
      trailing: trailing ?? (onTap != null ? const Icon(Icons.chevron_right, color: AppTheme.textGrey) : null),
    );
  }

  void _exportData(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('CSV export feature coming soon!')),
    );
  }

  void _confirmClear(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear All Data?'),
        content: const Text('This will permanently delete all accounts, transactions and cash entries. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Data cleared.')),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }
}
