import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_provider.dart';
import '../models/bank_account_model.dart';
import '../utils/app_theme.dart';
import '../utils/validators.dart';

class AddAccountScreen extends StatefulWidget {
  const AddAccountScreen({super.key});

  @override
  State<AddAccountScreen> createState() => _AddAccountScreenState();
}

class _AddAccountScreenState extends State<AddAccountScreen> {
  final _formKey = GlobalKey<FormState>();
  final _customBankCtrl = TextEditingController();
  final _accountNumCtrl = TextEditingController();
  final _balanceCtrl = TextEditingController(text: '0');

  String _selectedBank = popularBanks[0];
  String _selectedType = accountTypes[0];
  int _selectedColor = 0xFF6C63FF;
  bool _isCustomBank = false;

  final List<int> _colors = [
    0xFF6C63FF, 0xFFFF6584, 0xFF43B89C, 0xFFFF9F43,
    0xFF0984E3, 0xFFE056FD, 0xFF00B894, 0xFF2D3436,
  ];

  String get bankName => _isCustomBank ? _customBankCtrl.text : _selectedBank;

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final account = BankAccount(
      bankName: bankName,
      accountNumber: _accountNumCtrl.text.trim(),
      accountType: _selectedType,
      balance: double.tryParse(_balanceCtrl.text) ?? 0,
      color: _selectedColor,
    );
    await context.read<AppProvider>().addAccount(account);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Bank Account')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Preview Card
            _buildPreviewCard(),
            const SizedBox(height: 24),

            // Bank Name
            DropdownButtonFormField<String>(
              value: _selectedBank,
              decoration: const InputDecoration(labelText: 'Bank Name', prefixIcon: Icon(Icons.account_balance)),
              items: popularBanks.map((b) => DropdownMenuItem(value: b, child: Text(b))).toList(),
              onChanged: (v) {
                setState(() {
                  _selectedBank = v!;
                  _isCustomBank = v == 'Other';
                });
              },
            ),
            if (_isCustomBank) ...[
              const SizedBox(height: 16),
              TextFormField(
                controller: _customBankCtrl,
                decoration: const InputDecoration(labelText: 'Bank Name', prefixIcon: Icon(Icons.edit)),
                validator: (v) => _isCustomBank ? Validators.required(v, 'Bank name') : null,
              ),
            ],
            const SizedBox(height: 16),

            // Account Type
            DropdownButtonFormField<String>(
              value: _selectedType,
              decoration: const InputDecoration(labelText: 'Account Type', prefixIcon: Icon(Icons.category)),
              items: accountTypes.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
              onChanged: (v) => setState(() => _selectedType = v!),
            ),
            const SizedBox(height: 16),

            // Account Number
            TextFormField(
              controller: _accountNumCtrl,
              decoration: const InputDecoration(
                labelText: 'Account / Card Number (last 4 digits)',
                prefixIcon: Icon(Icons.credit_card),
                hintText: 'e.g. XXXX1234',
              ),
              validator: Validators.accountNumber,
            ),
            const SizedBox(height: 16),

            // Balance
            TextFormField(
              controller: _balanceCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Current Balance (₹)',
                prefixIcon: Icon(Icons.currency_rupee),
              ),
              validator: (v) => Validators.positiveNumber(v, 'Balance'),
            ),
            const SizedBox(height: 20),

            // Color Picker
            const Text('Card Color', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            const SizedBox(height: 12),
            Row(
              children: _colors.map((c) => GestureDetector(
                onTap: () => setState(() => _selectedColor = c),
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Color(c),
                    shape: BoxShape.circle,
                    border: _selectedColor == c ? Border.all(color: Colors.black, width: 2.5) : null,
                  ),
                  child: _selectedColor == c ? const Icon(Icons.check, color: Colors.white, size: 18) : null,
                ),
              )).toList(),
            ),
            const SizedBox(height: 32),

            ElevatedButton(
              onPressed: _submit,
              style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 52)),
              child: const Text('Add Account', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPreviewCard() {
    return Container(
      height: 130,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(_selectedColor), Color(_selectedColor).withOpacity(0.7)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Color(_selectedColor).withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 5))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8)),
                child: Text(bankName.isEmpty ? 'BANK' : bankName.substring(0, bankName.length > 4 ? 4 : bankName.length).toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
              Icon(_selectedType == 'Credit Card' ? Icons.credit_card : Icons.account_balance, color: Colors.white70),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(bankName.isEmpty ? 'Bank Name' : bankName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
              Text(_accountNumCtrl.text.isEmpty ? '••••••••' : _accountNumCtrl.text, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }
}
