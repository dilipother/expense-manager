import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_provider.dart';
import '../models/transaction_model.dart';
import '../utils/app_theme.dart';

class BudgetScreen extends StatefulWidget {
  const BudgetScreen({super.key});

  @override
  State<BudgetScreen> createState() => _BudgetScreenState();
}

class _BudgetScreenState extends State<BudgetScreen> {
  // In-memory budgets (could be persisted in DB too)
  final Map<String, double> _budgets = {
    'Food & Dining': 8000,
    'Shopping': 5000,
    'Transport': 3000,
    'Bills & Utilities': 4000,
    'Entertainment': 2000,
    'Health & Fitness': 2000,
  };

  void _editBudget(String category, double currentBudget) {
    final ctrl = TextEditingController(text: currentBudget.toStringAsFixed(0));
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Set Budget: $category'),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'Monthly budget (₹)',
            prefixIcon: Icon(Icons.currency_rupee),
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final v = double.tryParse(ctrl.text);
              if (v != null) setState(() => _budgets[category] = v);
              Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, provider, _) {
        final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
        final now = DateTime.now();
        final startOfMonth = DateTime(now.year, now.month, 1);

        // Spending per category this month
        final Map<String, double> spent = {};
        for (final txn in provider.transactions) {
          if (txn.type == 'expense' && txn.date.isAfter(startOfMonth)) {
            spent[txn.category] = (spent[txn.category] ?? 0) + txn.amount;
          }
        }

        final totalBudget = _budgets.values.fold(0.0, (s, v) => s + v);
        final totalSpent = spent.values.fold(0.0, (s, v) => s + v);
        final overallPct = totalBudget > 0 ? (totalSpent / totalBudget).clamp(0.0, 1.0) : 0.0;

        return Scaffold(
          backgroundColor: AppTheme.background,
          appBar: AppBar(title: const Text('Budget Tracker')),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Overall Summary
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [AppTheme.primary, Color(0xFF4A44B5)]),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: AppTheme.primary.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 6))],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Overall Budget', style: TextStyle(color: Colors.white70, fontSize: 13)),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(fmt.format(totalSpent), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
                        Text('/ ${fmt.format(totalBudget)}', style: const TextStyle(color: Colors.white70, fontSize: 16)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: overallPct,
                        backgroundColor: Colors.white24,
                        color: overallPct > 0.85 ? Colors.redAccent : Colors.white,
                        minHeight: 8,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${(overallPct * 100).toStringAsFixed(0)}% used  •  ${fmt.format(totalBudget - totalSpent)} remaining',
                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              const Text('Category Budgets', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),

              ..._budgets.entries.map((entry) {
                final cat = entry.key;
                final budget = entry.value;
                final catSpent = spent[cat] ?? 0;
                final pct = budget > 0 ? (catSpent / budget).clamp(0.0, 1.0) : 0.0;
                final isOver = catSpent > budget;
                final color = AppConstants.categoryColors[cat] ?? AppTheme.primary;
                final icon = AppConstants.categoryIcons[cat] ?? Icons.category;

                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: isOver ? Border.all(color: AppTheme.expense.withOpacity(0.4)) : null,
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                            child: Icon(icon, color: color, size: 18),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(cat, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                                Text(
                                  '${fmt.format(catSpent)} / ${fmt.format(budget)}',
                                  style: TextStyle(color: AppTheme.textGrey, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              if (isOver)
                                Text('Over budget!', style: TextStyle(color: AppTheme.expense, fontSize: 11, fontWeight: FontWeight.bold))
                              else
                                Text('${fmt.format(budget - catSpent)} left', style: TextStyle(color: AppTheme.income, fontSize: 11)),
                              Text('${(pct * 100).toStringAsFixed(0)}%', style: TextStyle(color: isOver ? AppTheme.expense : AppTheme.textGrey, fontWeight: FontWeight.bold)),
                            ],
                          ),
                          IconButton(
                            icon: const Icon(Icons.edit_outlined, size: 18, color: AppTheme.textGrey),
                            onPressed: () => _editBudget(cat, budget),
                            constraints: const BoxConstraints(),
                            padding: const EdgeInsets.only(left: 8),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: pct,
                          backgroundColor: color.withOpacity(0.1),
                          color: isOver ? AppTheme.expense : color,
                          minHeight: 6,
                        ),
                      ),
                    ],
                  ),
                );
              }),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }
}
