import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_provider.dart';
import '../models/transaction_model.dart';
import '../models/bank_account_model.dart';
import '../utils/app_theme.dart';
import 'add_transaction_screen.dart';

class AllTransactionsScreen extends StatefulWidget {
  const AllTransactionsScreen({super.key});

  @override
  State<AllTransactionsScreen> createState() => _AllTransactionsScreenState();
}

class _AllTransactionsScreenState extends State<AllTransactionsScreen> {
  String _filter = 'All';
  String _categoryFilter = 'All';

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, provider, _) {
        List<ExpenseTransaction> txns = provider.transactions;
        if (_filter == 'Income') txns = txns.where((t) => t.type == 'income').toList();
        if (_filter == 'Expense') txns = txns.where((t) => t.type == 'expense').toList();
        if (_filter == 'Cash') txns = txns.where((t) => t.isCash).toList();
        if (_categoryFilter != 'All') txns = txns.where((t) => t.category == _categoryFilter).toList();

        return Scaffold(
          backgroundColor: AppTheme.background,
          appBar: AppBar(
            title: const Text('All Transactions'),
            actions: [
              IconButton(
                icon: const Icon(Icons.add),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddTransactionScreen())),
              ),
            ],
          ),
          body: Column(
            children: [
              _buildFilters(),
              Expanded(
                child: txns.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.receipt_long, color: Colors.grey.shade400, size: 60),
                            const SizedBox(height: 12),
                            Text('No transactions found', style: TextStyle(color: Colors.grey.shade500, fontSize: 16)),
                          ],
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: txns.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (ctx, i) => _transactionCard(ctx, txns[i], provider),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFilters() {
    final filters = ['All', 'Income', 'Expense', 'Cash'];
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: filters.map((f) {
            final isSelected = _filter == f;
            return GestureDetector(
              onTap: () => setState(() => _filter = f),
              child: Container(
                margin: const EdgeInsets.only(right: 8),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected ? AppTheme.primary : AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(f, style: TextStyle(color: isSelected ? Colors.white : AppTheme.primary, fontWeight: FontWeight.w600, fontSize: 13)),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _transactionCard(BuildContext context, ExpenseTransaction txn, AppProvider provider) {
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    final icon = AppConstants.categoryIcons[txn.category] ?? Icons.more_horiz;
    final color = AppConstants.categoryColors[txn.category] ?? Colors.grey;
    final isIncome = txn.type == 'income';

    String accountName = txn.isCash ? '💵 Cash' : 'Bank Account';
    if (txn.accountId != null) {
      try {
        final acc = provider.accounts.firstWhere((a) => a.id == txn.accountId);
        accountName = '${acc.bankName} ${acc.maskedAccount}';
      } catch (_) {}
    }

    return Dismissible(
      key: Key('txn_${txn.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(16)),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      confirmDismiss: (_) async {
        return await showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Delete Transaction'),
            content: const Text('Are you sure?'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
              ElevatedButton(onPressed: () => Navigator.pop(ctx, true), style: ElevatedButton.styleFrom(backgroundColor: Colors.red), child: const Text('Delete')),
            ],
          ),
        );
      },
      onDismissed: (_) => provider.deleteTransaction(txn.id!),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(14)),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(txn.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text(txn.category, style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Icon(txn.isCash ? Icons.account_balance_wallet : Icons.account_balance, size: 12, color: AppTheme.textGrey),
                      const SizedBox(width: 4),
                      Text(accountName, style: TextStyle(color: AppTheme.textGrey, fontSize: 11)),
                      if (txn.smsSource != null) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                          decoration: BoxDecoration(color: AppTheme.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(4)),
                          child: const Text('SMS', style: TextStyle(color: AppTheme.primary, fontSize: 9, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '${isIncome ? '+' : '-'}${fmt.format(txn.amount)}',
                  style: TextStyle(color: isIncome ? AppTheme.income : AppTheme.expense, fontWeight: FontWeight.bold, fontSize: 16),
                ),
                const SizedBox(height: 4),
                Text(DateFormat('dd MMM yyyy').format(txn.date), style: TextStyle(color: AppTheme.textGrey, fontSize: 11)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
