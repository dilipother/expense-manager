import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_provider.dart';
import '../models/transaction_model.dart';
import '../models/bank_account_model.dart';
import '../utils/app_theme.dart';
import '../utils/validators.dart';

/// Transfer money from one bank account to another (or to/from cash).
class TransferScreen extends StatefulWidget {
  const TransferScreen({super.key});

  @override
  State<TransferScreen> createState() => _TransferScreenState();
}

class _TransferScreenState extends State<TransferScreen> {
  final _formKey = GlobalKey<FormState>();
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();

  int? _fromAccountId;     // null = cash
  int? _toAccountId;       // null = cash
  bool _fromIsCash = false;
  bool _toIsCash = false;
  DateTime _date = DateTime.now();

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final provider = context.read<AppProvider>();
    final amount = double.parse(_amountCtrl.text);
    final note = _noteCtrl.text.trim().isEmpty ? 'Transfer' : _noteCtrl.text.trim();

    // Debit from source
    final debit = ExpenseTransaction(
      title: 'Transfer Out',
      amount: amount,
      type: 'expense',
      category: 'Others',
      accountId: _fromIsCash ? null : _fromAccountId,
      isCash: _fromIsCash,
      note: note,
      date: _date,
    );

    // Credit to destination
    final credit = ExpenseTransaction(
      title: 'Transfer In',
      amount: amount,
      type: 'income',
      category: 'Others',
      accountId: _toIsCash ? null : _toAccountId,
      isCash: _toIsCash,
      note: note,
      date: _date,
    );

    await provider.addTransaction(debit);
    await provider.addTransaction(credit);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('₹${amount.toStringAsFixed(0)} transferred successfully'),
          backgroundColor: AppTheme.income,
        ),
      );
      Navigator.pop(context);
    }
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (d != null) setState(() => _date = d);
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();
    final accounts = provider.accounts;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Transfer Money')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Visual flow diagram
            _buildFlowCard(provider),
            const SizedBox(height: 24),

            // Amount
            TextFormField(
              controller: _amountCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Amount (₹)',
                prefixIcon: Icon(Icons.currency_rupee),
              ),
              validator: Validators.amount,
            ),
            const SizedBox(height: 16),

            // From
            const Text('From', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppTheme.textGrey)),
            const SizedBox(height: 8),
            _sourceSelector(
              label: 'From Account',
              isCash: _fromIsCash,
              selectedId: _fromAccountId,
              accounts: accounts,
              onCashChanged: (v) => setState(() { _fromIsCash = v; _fromAccountId = null; }),
              onAccountChanged: (v) => setState(() => _fromAccountId = v),
            ),
            const SizedBox(height: 16),

            // Arrow
            Center(
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.arrow_downward, color: AppTheme.primary),
              ),
            ),
            const SizedBox(height: 16),

            // To
            const Text('To', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppTheme.textGrey)),
            const SizedBox(height: 8),
            _sourceSelector(
              label: 'To Account',
              isCash: _toIsCash,
              selectedId: _toAccountId,
              accounts: accounts,
              onCashChanged: (v) => setState(() { _toIsCash = v; _toAccountId = null; }),
              onAccountChanged: (v) => setState(() => _toAccountId = v),
            ),
            const SizedBox(height: 16),

            // Date
            GestureDetector(
              onTap: _pickDate,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.calendar_today, color: AppTheme.textGrey, size: 20),
                    const SizedBox(width: 12),
                    Text(DateFormat('dd MMMM, yyyy').format(_date), style: const TextStyle(fontSize: 16)),
                    const Spacer(),
                    const Icon(Icons.arrow_drop_down, color: AppTheme.textGrey),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Note
            TextFormField(
              controller: _noteCtrl,
              decoration: const InputDecoration(
                labelText: 'Note (optional)',
                prefixIcon: Icon(Icons.note_outlined),
              ),
            ),
            const SizedBox(height: 32),

            ElevatedButton.icon(
              onPressed: _submit,
              icon: const Icon(Icons.swap_horiz),
              label: const Text('Transfer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 52)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFlowCard(AppProvider provider) {
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);

    String fromLabel = _fromIsCash ? '💵 Cash' : (_fromAccountId != null
        ? provider.accounts.firstWhere((a) => a.id == _fromAccountId, orElse: () => BankAccount(bankName: 'Select', accountNumber: '', accountType: 'Savings', balance: 0, color: 0xFF6C63FF)).bankName
        : 'Select Source');

    String toLabel = _toIsCash ? '💵 Cash' : (_toAccountId != null
        ? provider.accounts.firstWhere((a) => a.id == _toAccountId, orElse: () => BankAccount(bankName: 'Select', accountNumber: '', accountType: 'Savings', balance: 0, color: 0xFF6C63FF)).bankName
        : 'Select Destination');

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [AppTheme.primary, Color(0xFF4A44B5)]),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _flowNode(fromLabel, Icons.account_balance, isSource: true),
          Column(
            children: [
              const Icon(Icons.arrow_forward, color: Colors.white, size: 28),
              if (_amountCtrl.text.isNotEmpty)
                Text('₹${_amountCtrl.text}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
          _flowNode(toLabel, Icons.account_balance_wallet, isSource: false),
        ],
      ),
    );
  }

  Widget _flowNode(String label, IconData icon, {required bool isSource}) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: isSource ? Colors.redAccent.withOpacity(0.3) : Colors.greenAccent.withOpacity(0.3),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: Colors.white, size: 24),
        ),
        const SizedBox(height: 6),
        SizedBox(
          width: 80,
          child: Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600), maxLines: 2, overflow: TextOverflow.ellipsis),
        ),
      ],
    );
  }

  Widget _sourceSelector({
    required String label,
    required bool isCash,
    required int? selectedId,
    required List<BankAccount> accounts,
    required ValueChanged<bool> onCashChanged,
    required ValueChanged<int?> onAccountChanged,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Cash toggle
          GestureDetector(
            onTap: () => onCashChanged(!isCash),
            child: Row(
              children: [
                Container(
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: AppTheme.orange, width: 2),
                    color: isCash ? AppTheme.orange : Colors.transparent,
                  ),
                  child: isCash ? const Icon(Icons.check, color: Colors.white, size: 12) : null,
                ),
                const SizedBox(width: 10),
                const Icon(Icons.account_balance_wallet, color: AppTheme.orange, size: 18),
                const SizedBox(width: 6),
                const Text('Cash', style: TextStyle(fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          if (!isCash) ...[
            const Divider(height: 20),
            DropdownButtonHideUnderline(
              child: DropdownButton<int?>(
                value: selectedId,
                hint: Text(label, style: TextStyle(color: AppTheme.textGrey)),
                isExpanded: true,
                items: accounts.map((a) => DropdownMenuItem(
                  value: a.id,
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(color: a.colorValue.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                        child: Text(a.bankInitials, style: TextStyle(color: a.colorValue, fontWeight: FontWeight.bold, fontSize: 11)),
                      ),
                      const SizedBox(width: 8),
                      Expanded(child: Text('${a.bankName} ${a.maskedAccount}', overflow: TextOverflow.ellipsis)),
                    ],
                  ),
                )).toList(),
                onChanged: onAccountChanged,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
