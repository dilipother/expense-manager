import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_provider.dart';
import '../models/bank_account_model.dart';
import '../models/transaction_model.dart';
import '../utils/app_theme.dart';
import 'add_transaction_screen.dart';

class AccountDetailScreen extends StatelessWidget {
  final BankAccount account;
  const AccountDetailScreen({super.key, required this.account});

  @override
  Widget build(BuildContext context) {
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    return Consumer<AppProvider>(
      builder: (context, provider, _) {
        final txns = provider.getTransactionsByAccount(account.id!);
        final income = txns.where((t) => t.type == 'income').fold(0.0, (s, t) => s + t.amount);
        final expense = txns.where((t) => t.type == 'expense').fold(0.0, (s, t) => s + t.amount);

        return Scaffold(
          backgroundColor: AppTheme.background,
          appBar: AppBar(
            title: Text(account.bankName),
            backgroundColor: account.colorValue,
            actions: [
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Delete Account'),
                      content: const Text('All transactions for this account will be removed.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                        ElevatedButton(onPressed: () => Navigator.pop(ctx, true), style: ElevatedButton.styleFrom(backgroundColor: Colors.red), child: const Text('Delete')),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    await provider.deleteAccount(account.id!);
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
            ],
          ),
          body: ListView(
            children: [
              // Header Card
              Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [account.colorValue, account.colorValue.withOpacity(0.7)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: account.colorValue.withOpacity(0.3), blurRadius: 15, offset: const Offset(0, 8))],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(12)),
                          child: Text(account.bankInitials, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(account.bankName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                            Text(account.accountType, style: const TextStyle(color: Colors.white70, fontSize: 13)),
                          ],
                        ),
                        const Spacer(),
                        Icon(account.isCreditCard ? Icons.credit_card : Icons.account_balance, color: Colors.white70, size: 28),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const Text('Balance', style: TextStyle(color: Colors.white70, fontSize: 13)),
                    Text(
                      account.balance < 0 ? '-${fmt.format(account.balance.abs())}' : fmt.format(account.balance),
                      style: TextStyle(
                        color: account.balance < 0 ? Colors.red.shade200 : Colors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(account.maskedAccount, style: const TextStyle(color: Colors.white60, fontSize: 13)),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(child: _statItem('Income', fmt.format(income), Icons.arrow_downward, Colors.greenAccent)),
                        Container(width: 1, height: 40, color: Colors.white24),
                        Expanded(child: _statItem('Expense', fmt.format(expense), Icons.arrow_upward, Colors.redAccent)),
                        Container(width: 1, height: 40, color: Colors.white24),
                        Expanded(child: _statItem('Txns', txns.length.toString(), Icons.receipt_long, Colors.white70)),
                      ],
                    ),
                  ],
                ),
              ),

              // Add Transaction Button
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddTransactionScreen())),
                  icon: const Icon(Icons.add),
                  label: const Text('Add Transaction'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: account.colorValue,
                    minimumSize: const Size(double.infinity, 48),
                  ),
                ),
              ),

              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: const Text('Transactions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 8),

              if (txns.isEmpty)
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(
                      children: [
                        Icon(Icons.receipt_long, color: Colors.grey.shade400, size: 40),
                        const SizedBox(height: 8),
                        Text('No transactions', style: TextStyle(color: Colors.grey.shade500)),
                      ],
                    ),
                  ),
                )
              else
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Container(
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                    child: ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: txns.length,
                      separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey.shade100, indent: 68),
                      itemBuilder: (ctx, i) => _txnTile(txns[i]),
                    ),
                  ),
                ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  Widget _statItem(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(height: 4),
        Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
        Text(label, style: const TextStyle(color: Colors.white60, fontSize: 10)),
      ],
    );
  }

  Widget _txnTile(ExpenseTransaction txn) {
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    final icon = AppConstants.categoryIcons[txn.category] ?? Icons.more_horiz;
    final color = AppConstants.categoryColors[txn.category] ?? Colors.grey;
    final isIncome = txn.type == 'income';

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
        child: Icon(icon, color: color, size: 20),
      ),
      title: Text(txn.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
      subtitle: Text('${txn.category} • ${DateFormat('dd MMM').format(txn.date)}', style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
      trailing: Text(
        '${isIncome ? '+' : '-'}${fmt.format(txn.amount)}',
        style: TextStyle(color: isIncome ? AppTheme.income : AppTheme.expense, fontWeight: FontWeight.bold),
      ),
    );
  }
}
