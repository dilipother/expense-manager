import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_provider.dart';
import '../models/cash_model.dart';
import '../models/transaction_model.dart';
import '../utils/app_theme.dart';
import 'add_transaction_screen.dart';

class CashScreen extends StatelessWidget {
  const CashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, provider, _) {
        final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
        return Scaffold(
          backgroundColor: AppTheme.background,
          appBar: AppBar(
            title: const Text('Cash Wallet'),
            backgroundColor: AppTheme.orange,
            actions: [
              IconButton(
                icon: const Icon(Icons.add_circle_outline),
                onPressed: () => _showAddCashDialog(context, provider),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Cash on Hand Card
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFFF9F43), Color(0xFFFF6B35)]),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: AppTheme.orange.withOpacity(0.3), blurRadius: 15, offset: const Offset(0, 8))],
                ),
                child: Column(
                  children: [
                    const Icon(Icons.account_balance_wallet, color: Colors.white, size: 48),
                    const SizedBox(height: 12),
                    const Text('Cash on Hand', style: TextStyle(color: Colors.white70, fontSize: 14)),
                    const SizedBox(height: 4),
                    Text(fmt.format(provider.cashOnHand), style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(child: _actionButton(context, 'Add Cash', Icons.add, Colors.white24, () => _showAddCashDialog(context, provider, type: 'add'))),
                        const SizedBox(width: 12),
                        Expanded(child: _actionButton(context, 'ATM Withdraw', Icons.atm, Colors.white24, () => _showAddCashDialog(context, provider, type: 'atm_withdraw'))),
                        const SizedBox(width: 12),
                        Expanded(child: _actionButton(context, 'Spend Cash', Icons.shopping_cart, Colors.white24, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddTransactionScreen(isCash: true))))),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Cash Transactions
              const Text('Cash History', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              if (provider.cashEntries.isEmpty)
                Container(
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(Icons.account_balance_wallet_outlined, color: Colors.grey.shade400, size: 40),
                        const SizedBox(height: 8),
                        Text('No cash entries yet', style: TextStyle(color: Colors.grey.shade500)),
                      ],
                    ),
                  ),
                )
              else
                Container(
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
                  ),
                  child: ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: provider.cashEntries.length,
                    separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey.shade100, indent: 68),
                    itemBuilder: (ctx, i) => _cashEntryTile(provider.cashEntries[i]),
                  ),
                ),

              // Cash Transactions from expense tracker
              const SizedBox(height: 16),
              const Text('Cash Expenses', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildCashExpenses(context, provider),
            ],
          ),
        );
      },
    );
  }

  Widget _actionButton(BuildContext context, String label, IconData icon, Color bgColor, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(height: 4),
            Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }

  Widget _cashEntryTile(CashEntry entry) {
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    final isIn = entry.isInflow;
    IconData icon;
    Color color;
    switch (entry.type) {
      case 'add':
        icon = Icons.add_circle;
        color = AppTheme.income;
        break;
      case 'atm_withdraw':
        icon = Icons.atm;
        color = AppTheme.primary;
        break;
      default:
        icon = Icons.remove_circle;
        color = AppTheme.expense;
    }

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
        child: Icon(icon, color: color, size: 20),
      ),
      title: Text(entry.typeLabel, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
      subtitle: Text(entry.description ?? DateFormat('dd MMM yyyy').format(entry.date), style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
      trailing: Text(
        '${isIn ? '+' : '-'}${fmt.format(entry.amount)}',
        style: TextStyle(color: isIn ? AppTheme.income : AppTheme.expense, fontWeight: FontWeight.bold, fontSize: 14),
      ),
    );
  }

  Widget _buildCashExpenses(BuildContext context, AppProvider provider) {
    final cashTxns = provider.transactions.where((t) => t.isCash).toList();
    if (cashTxns.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: Center(child: Text('No cash expenses', style: TextStyle(color: Colors.grey.shade500))),
      );
    }
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
      ),
      child: ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: cashTxns.length,
        separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey.shade100, indent: 68),
        itemBuilder: (ctx, i) {
          final txn = cashTxns[i];
          final isIncome = txn.type == 'income';
          return ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: AppTheme.orange.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.account_balance_wallet, color: AppTheme.orange, size: 20),
            ),
            title: Text(txn.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            subtitle: Text('${txn.category} • ${DateFormat('dd MMM').format(txn.date)}', style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
            trailing: Text(
              '${isIncome ? '+' : '-'}${fmt.format(txn.amount)}',
              style: TextStyle(color: isIncome ? AppTheme.income : AppTheme.expense, fontWeight: FontWeight.bold, fontSize: 14),
            ),
          );
        },
      ),
    );
  }

  void _showAddCashDialog(BuildContext context, AppProvider provider, {String type = 'add'}) {
    final amountCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    String selectedType = type;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return Padding(
              padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom, left: 24, right: 24, top: 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Cash Entry', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  // Type Selector
                  Row(
                    children: [
                      _typeChip('Add Cash', 'add', selectedType, (v) => setModalState(() => selectedType = v), AppTheme.income),
                      const SizedBox(width: 8),
                      _typeChip('ATM Withdraw', 'atm_withdraw', selectedType, (v) => setModalState(() => selectedType = v), AppTheme.primary),
                      const SizedBox(width: 8),
                      _typeChip('Spend', 'spend', selectedType, (v) => setModalState(() => selectedType = v), AppTheme.expense),
                    ],
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: amountCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'Amount (₹)', prefixIcon: Icon(Icons.currency_rupee)),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: descCtrl,
                    decoration: const InputDecoration(labelText: 'Description (optional)', prefixIcon: Icon(Icons.note_outlined)),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      if (amountCtrl.text.isEmpty) return;
                      final amount = double.tryParse(amountCtrl.text);
                      if (amount == null) return;
                      final entry = CashEntry(
                        type: selectedType,
                        amount: amount,
                        description: descCtrl.text.isEmpty ? null : descCtrl.text,
                        date: DateTime.now(),
                      );
                      await provider.addCashEntry(entry);
                      Navigator.pop(ctx);
                    },
                    style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 48)),
                    child: const Text('Save'),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _typeChip(String label, String value, String selected, Function(String) onTap, Color color) {
    final isSelected = selected == value;
    return GestureDetector(
      onTap: () => onTap(value),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? color : color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(label, style: TextStyle(color: isSelected ? Colors.white : color, fontSize: 12, fontWeight: FontWeight.w600)),
      ),
    );
  }
}
