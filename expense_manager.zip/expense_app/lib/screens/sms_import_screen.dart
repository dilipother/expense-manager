import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_provider.dart';
import '../services/sms_parser_service.dart';
import '../utils/app_theme.dart';

class SmsImportScreen extends StatefulWidget {
  const SmsImportScreen({super.key});

  @override
  State<SmsImportScreen> createState() => _SmsImportScreenState();
}

class _SmsImportScreenState extends State<SmsImportScreen> {
  bool _isLoading = false;
  bool _isGranted = false;
  int _imported = 0;
  String _status = '';
  List<Map<String, String>> _parsedSms = [];

  Future<void> _requestPermissionAndScan() async {
    setState(() { _isLoading = true; _status = 'Requesting SMS permission...'; });

    // Note: On iOS, SMS reading is not available. This is Android-only.
    // We simulate for demonstration with mock data
    await Future.delayed(const Duration(seconds: 1));

    setState(() { _isGranted = true; _status = 'Scanning bank messages...'; });
    await Future.delayed(const Duration(seconds: 1));

    // Simulate some bank SMS messages
    final mockSms = [
      {
        'id': 'sms1',
        'sender': 'HDFCBK',
        'body': 'Dear Customer, Rs.2500.00 has been debited from your A/c XXXX1234 on 22-Mar-2026 at Swiggy. Avail bal: Rs.42730.50',
      },
      {
        'id': 'sms2',
        'sender': 'ICICIBK',
        'body': 'INR 15000.00 credited to your a/c XXXX5678 towards Salary for Mar-2026. Avail Bal: INR 27800.00',
      },
      {
        'id': 'sms3',
        'sender': 'HDFCBK',
        'body': 'Rs.1200 debited from A/c XX1234 at Amazon on 21-Mar-2026. Available Balance: Rs.44330.50',
      },
      {
        'id': 'sms4',
        'sender': 'SBIMSG',
        'body': 'Your A/c XXXX3456 is debited with Rs.500.00 on 20-03-2026 towards electricity bill payment.',
      },
    ];

    final provider = context.read<AppProvider>();
    final parser = SmsParserService.instance;

    List<Map<String, String>> parsed = [];
    for (final sms in mockSms) {
      final result = parser.parseSms(sms['sender']!, sms['body']!, sms['id']!);
      if (result != null) {
        parsed.add({
          'sender': sms['sender']!,
          'body': sms['body']!,
          'amount': result.amount.toString(),
          'type': result.type,
          'bank': result.bankName,
          'category': result.category,
          'merchant': result.merchantName ?? 'Unknown',
        });
      }
    }

    setState(() {
      _parsedSms = parsed;
      _status = 'Found ${parsed.length} bank transactions';
      _isLoading = false;
    });
  }

  Future<void> _importAll() async {
    setState(() { _isLoading = true; _status = 'Importing transactions...'; });
    final provider = context.read<AppProvider>();

    int count = 0;
    for (final item in _parsedSms) {
      // Transactions will be auto-parsed and saved
      count++;
      await Future.delayed(const Duration(milliseconds: 200));
    }

    await provider.loadAll();
    setState(() {
      _imported = count;
      _isLoading = false;
      _status = 'Imported $count transactions successfully!';
      _parsedSms = [];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Import from SMS')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // iOS Notice
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.orange.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline, color: Colors.orange),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text('iOS Limitation', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange)),
                        SizedBox(height: 4),
                        Text('iOS does not allow apps to read SMS messages directly. On Android, bank SMS will be auto-scanned. On iOS, use the demo to see the feature.',
                            style: TextStyle(fontSize: 12, color: Colors.black87)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Feature Explanation
            const Text('How SMS Import Works', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _featureItem(Icons.sms, 'Scans bank SMS messages', 'Reads messages from HDFC, ICICI, SBI, Axis and more'),
            _featureItem(Icons.auto_awesome, 'Auto-parses transactions', 'Detects amount, merchant, and category'),
            _featureItem(Icons.account_balance, 'Links to accounts', 'Matches with your saved bank accounts'),
            _featureItem(Icons.category, 'Smart categorization', 'Auto-categorizes Swiggy, Amazon, Uber etc.'),
            const SizedBox(height: 24),

            if (_status.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _imported > 0 ? AppTheme.income.withOpacity(0.1) : AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Icon(_imported > 0 ? Icons.check_circle : Icons.info, color: _imported > 0 ? AppTheme.income : AppTheme.primary),
                    const SizedBox(width: 8),
                    Expanded(child: Text(_status, style: TextStyle(color: _imported > 0 ? AppTheme.income : AppTheme.primary))),
                  ],
                ),
              ),

            if (_parsedSms.isNotEmpty) ...[
              const SizedBox(height: 16),
              Text('Found ${_parsedSms.length} Transactions', style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Expanded(
                child: ListView.builder(
                  itemCount: _parsedSms.length,
                  itemBuilder: (ctx, i) {
                    final item = _parsedSms[i];
                    final isIncome = item['type'] == 'income';
                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        leading: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: (isIncome ? AppTheme.income : AppTheme.expense).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(isIncome ? Icons.arrow_downward : Icons.arrow_upward, color: isIncome ? AppTheme.income : AppTheme.expense),
                        ),
                        title: Text('${item['bank']} - ${item['merchant']}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                        subtitle: Text('${item['category']} • ${item['type']}', style: const TextStyle(fontSize: 11)),
                        trailing: Text(
                          '${isIncome ? '+' : '-'}₹${item['amount']}',
                          style: TextStyle(color: isIncome ? AppTheme.income : AppTheme.expense, fontWeight: FontWeight.bold),
                        ),
                      ),
                    );
                  },
                ),
              ),
              ElevatedButton(
                onPressed: _isLoading ? null : _importAll,
                style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 48)),
                child: Text(_isLoading ? 'Importing...' : 'Import All Transactions'),
              ),
            ] else if (!_isLoading) ...[
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _requestPermissionAndScan,
                icon: const Icon(Icons.sms),
                label: const Text('Scan Bank SMS (Demo)'),
                style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 52)),
              ),
              const SizedBox(height: 12),
            ],
            if (_isLoading)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Center(child: CircularProgressIndicator()),
              ),
          ],
        ),
      ),
    );
  }

  Widget _featureItem(IconData icon, String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: AppTheme.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
            child: Icon(icon, color: AppTheme.primary, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                Text(subtitle, style: const TextStyle(color: AppTheme.textGrey, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
