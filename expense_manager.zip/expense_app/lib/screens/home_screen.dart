import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_provider.dart';
import '../utils/app_theme.dart';
import '../models/bank_account_model.dart';
import '../models/transaction_model.dart';
import 'add_transaction_screen.dart';
import 'add_account_screen.dart';
import 'cash_screen.dart';
import 'all_transactions_screen.dart';
import 'account_detail_screen.dart';
import 'sms_import_screen.dart';
import 'analytics_screen.dart';
import 'settings_screen.dart';
import 'transfer_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _pages = [
    const _HomeTab(),
    const AllTransactionsScreen(),
    const AnalyticsScreen(),
    const CashScreen(),
    const SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_currentIndex],
      bottomNavigationBar: _buildBottomNav(),
      floatingActionButton: _currentIndex == 0 ? _buildFab() : null,
    );
  }

  Widget _buildFab() {
    return FloatingActionButton.extended(
      onPressed: () => _showAddMenu(context),
      backgroundColor: AppTheme.primary,
      icon: const Icon(Icons.add, color: Colors.white),
      label: const Text('Add', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
    );
  }

  void _showAddMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 36),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('What would you like to add?', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 20),
            _menuItem(ctx, Icons.arrow_upward, 'Add Expense', 'Record a payment or spend', AppTheme.expense,
                () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const AddTransactionScreen()))),
            const SizedBox(height: 12),
            _menuItem(ctx, Icons.arrow_downward, 'Add Income', 'Record salary, freelance, etc.', AppTheme.income,
                () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const AddTransactionScreen()))),
            const SizedBox(height: 12),
            _menuItem(ctx, Icons.swap_horiz, 'Transfer', 'Move money between accounts', AppTheme.primary,
                () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const TransferScreen()))),
            const SizedBox(height: 12),
            _menuItem(ctx, Icons.account_balance_wallet, 'Cash Entry', 'Add cash or ATM withdrawal', AppTheme.orange,
                () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => const CashScreen()))),
          ],
        ),
      ),
    );
  }

  Widget _menuItem(BuildContext ctx, IconData icon, String title, String subtitle, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: () { Navigator.pop(ctx); onTap(); },
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.07),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: color, fontSize: 15)),
                  Text(subtitle, style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: color.withOpacity(0.5)),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    return NavigationBar(
      selectedIndex: _currentIndex,
      onDestinationSelected: (i) => setState(() => _currentIndex = i),
      backgroundColor: Colors.white,
      elevation: 8,
      shadowColor: Colors.black26,
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Transactions'),
        NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Analytics'),
        NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Cash'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
      ],
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, provider, child) {
        return Scaffold(
          backgroundColor: AppTheme.background,
          body: CustomScrollView(
            slivers: [
              _buildAppBar(context, provider),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildNetWorthCard(provider),
                      const SizedBox(height: 20),
                      _buildSummaryCards(provider),
                      const SizedBox(height: 20),
                      _buildCashCard(context, provider),
                      const SizedBox(height: 20),
                      _buildAccountsSection(context, provider),
                      const SizedBox(height: 20),
                      _buildRecentTransactions(context, provider),
                      const SizedBox(height: 80),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildAppBar(BuildContext context, AppProvider provider) {
    return SliverAppBar(
      expandedHeight: 100,
      pinned: true,
      backgroundColor: AppTheme.primary,
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppTheme.primary, Color(0xFF4A44B5)],
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Good ${_getGreeting()}! 👋',
                        style: const TextStyle(color: Colors.white70, fontSize: 14),
                      ),
                      const Text(
                        'My Finances',
                        style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      if (provider.smsCount > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            '${provider.smsCount} SMS',
                            style: const TextStyle(color: Colors.white, fontSize: 12),
                          ),
                        ),
                      IconButton(
                        icon: const Icon(Icons.sms, color: Colors.white),
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SmsImportScreen())),
                        tooltip: 'Import from SMS',
                      ),
                      IconButton(
                        icon: const Icon(Icons.notifications_outlined, color: Colors.white),
                        onPressed: () {},
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Morning';
    if (hour < 17) return 'Afternoon';
    return 'Evening';
  }

  Widget _buildNetWorthCard(AppProvider provider) {
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppTheme.primary, Color(0xFF4A44B5)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: AppTheme.primary.withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Net Worth', style: TextStyle(color: Colors.white70, fontSize: 14)),
          const SizedBox(height: 4),
          Text(
            fmt.format(provider.netWorth),
            style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _netWorthItem('Bank Balance', fmt.format(provider.totalBankBalance), Icons.account_balance),
              Container(width: 1, height: 40, color: Colors.white24),
              _netWorthItem('Credit Used', fmt.format(provider.totalCreditUsed), Icons.credit_card),
              Container(width: 1, height: 40, color: Colors.white24),
              _netWorthItem('Cash', fmt.format(provider.cashOnHand), Icons.wallet),
            ],
          ),
        ],
      ),
    );
  }

  Widget _netWorthItem(String label, String value, IconData icon) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: Colors.white70, size: 16),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
          Text(label, style: const TextStyle(color: Colors.white60, fontSize: 10)),
        ],
      ),
    );
  }

  Widget _buildSummaryCards(AppProvider provider) {
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    return Row(
      children: [
        Expanded(
          child: _summaryCard('Income', fmt.format(provider.monthlySummary['income'] ?? 0), Icons.arrow_downward, AppTheme.income),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _summaryCard('Expense', fmt.format(provider.monthlySummary['expense'] ?? 0), Icons.arrow_upward, AppTheme.expense),
        ),
      ],
    );
  }

  Widget _summaryCard(String title, String amount, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                child: Icon(icon, color: color, size: 16),
              ),
              const SizedBox(width: 8),
              Text('This Month', style: TextStyle(color: AppTheme.textGrey, fontSize: 11)),
            ],
          ),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(color: AppTheme.textGrey, fontSize: 13)),
          Text(amount, style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildCashCard(BuildContext context, AppProvider provider) {
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CashScreen())),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFFFF9F43), Color(0xFFFF6B35)]),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: AppTheme.orange.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 5))],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.account_balance_wallet, color: Colors.white, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Cash on Hand', style: TextStyle(color: Colors.white70, fontSize: 13)),
                  Text(fmt.format(provider.cashOnHand), style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            Column(
              children: [
                const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 16),
                const SizedBox(height: 4),
                Text('Manage', style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccountsSection(BuildContext context, AppProvider provider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Bank Accounts & Cards', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.textDark)),
            TextButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddAccountScreen())),
              icon: const Icon(Icons.add, size: 16),
              label: const Text('Add'),
              style: TextButton.styleFrom(foregroundColor: AppTheme.primary),
            ),
          ],
        ),
        const SizedBox(height: 8),
        if (provider.accounts.isEmpty)
          _emptyAccountsCard(context)
        else
          SizedBox(
            height: 130,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: provider.accounts.length + 1,
              itemBuilder: (context, i) {
                if (i == provider.accounts.length) {
                  return _addAccountCard(context);
                }
                return _accountCard(context, provider.accounts[i]);
              },
            ),
          ),
      ],
    );
  }

  Widget _accountCard(BuildContext context, BankAccount account) {
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    final isNeg = account.balance < 0;
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AccountDetailScreen(account: account))),
      child: Container(
        width: 180,
        margin: const EdgeInsets.only(right: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [account.colorValue, account.colorValue.withOpacity(0.7)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: account.colorValue.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8)),
                  child: Text(account.bankInitials, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                ),
                Icon(account.isCreditCard ? Icons.credit_card : Icons.account_balance, color: Colors.white70, size: 18),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(account.bankName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                Text(account.maskedAccount, style: const TextStyle(color: Colors.white70, fontSize: 11)),
                const SizedBox(height: 2),
                Text(
                  isNeg ? '-${fmt.format(account.balance.abs())}' : fmt.format(account.balance),
                  style: TextStyle(color: isNeg ? Colors.red.shade200 : Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _addAccountCard(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddAccountScreen())),
      child: Container(
        width: 100,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          border: Border.all(color: AppTheme.primary.withOpacity(0.3), width: 2),
          borderRadius: BorderRadius.circular(16),
          color: AppTheme.primary.withOpacity(0.05),
        ),
        child: const Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.add_circle_outline, color: AppTheme.primary, size: 32),
            SizedBox(height: 4),
            Text('Add\nAccount', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.primary, fontSize: 12, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }

  Widget _emptyAccountsCard(BuildContext context) {
    return Container(
      height: 100,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.account_balance, color: Colors.grey.shade400, size: 28),
            const SizedBox(height: 4),
            Text('No accounts yet', style: TextStyle(color: Colors.grey.shade500)),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentTransactions(BuildContext context, AppProvider provider) {
    final recent = provider.getRecentTransactions(limit: 5);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Recent Transactions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.textDark)),
            TextButton(
              onPressed: () {},
              child: const Text('See All', style: TextStyle(color: AppTheme.primary)),
            ),
          ],
        ),
        if (recent.isEmpty)
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
            child: Center(
              child: Column(
                children: [
                  Icon(Icons.receipt_long, color: Colors.grey.shade400, size: 40),
                  const SizedBox(height: 8),
                  Text('No transactions yet', style: TextStyle(color: Colors.grey.shade500)),
                  const SizedBox(height: 4),
                  Text('Add transactions or import from SMS', style: TextStyle(color: Colors.grey.shade400, fontSize: 12)),
                ],
              ),
            ),
          )
        else
          Container(
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
            ),
            child: ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: recent.length,
              separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey.shade100, indent: 68),
              itemBuilder: (ctx, i) => _transactionTile(recent[i], provider),
            ),
          ),
      ],
    );
  }

  Widget _transactionTile(ExpenseTransaction txn, AppProvider provider) {
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    final icon = AppConstants.categoryIcons[txn.category] ?? Icons.more_horiz;
    final color = AppConstants.categoryColors[txn.category] ?? Colors.grey;
    final isIncome = txn.type == 'income';

    // Get bank name
    String subtitle = txn.isCash ? 'Cash' : 'Account';
    if (txn.accountId != null) {
      final acc = provider.accounts.firstWhere((a) => a.id == txn.accountId, orElse: () => BankAccount(bankName: 'Bank', accountNumber: '', accountType: 'Savings', balance: 0, color: 0xFF6C63FF));
      subtitle = acc.bankName;
    }

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
        child: Icon(icon, color: color, size: 20),
      ),
      title: Text(txn.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
      subtitle: Text('${txn.category} • $subtitle', style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            '${isIncome ? '+' : '-'}${fmt.format(txn.amount)}',
            style: TextStyle(color: isIncome ? AppTheme.income : AppTheme.expense, fontWeight: FontWeight.bold, fontSize: 14),
          ),
          Text(DateFormat('dd MMM').format(txn.date), style: TextStyle(color: AppTheme.textGrey, fontSize: 11)),
        ],
      ),
    );
  }
}
