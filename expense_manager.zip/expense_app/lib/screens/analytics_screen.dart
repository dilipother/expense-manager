import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import '../services/app_provider.dart';
import '../models/transaction_model.dart';
import '../utils/app_theme.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, provider, _) {
        final txns = provider.transactions;
        final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);

        // Category breakdown
        final Map<String, double> categoryMap = {};
        for (final t in txns.where((t) => t.type == 'expense')) {
          categoryMap[t.category] = (categoryMap[t.category] ?? 0) + t.amount;
        }
        final sorted = categoryMap.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
        final totalExpense = sorted.fold(0.0, (s, e) => s + e.value);

        // Monthly trend (last 6 months)
        final monthlyData = _getMonthlyData(txns);

        return Scaffold(
          backgroundColor: AppTheme.background,
          appBar: AppBar(title: const Text('Analytics')),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Summary
              _buildSummarySection(provider, fmt),
              const SizedBox(height: 20),

              // Pie Chart
              if (sorted.isNotEmpty) ...[
                const Text('Spending by Category', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
                  ),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 200,
                        child: PieChart(
                          PieChartData(
                            sections: sorted.take(6).map((e) {
                              final color = AppConstants.categoryColors[e.key] ?? Colors.grey;
                              final pct = totalExpense > 0 ? e.value / totalExpense * 100 : 0;
                              return PieChartSectionData(
                                color: color,
                                value: e.value,
                                title: '${pct.toStringAsFixed(0)}%',
                                titleStyle: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                                radius: 80,
                              );
                            }).toList(),
                            sectionsSpace: 2,
                            centerSpaceRadius: 40,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      ...sorted.take(6).map((e) {
                        final color = AppConstants.categoryColors[e.key] ?? Colors.grey;
                        final pct = totalExpense > 0 ? e.value / totalExpense * 100 : 0;
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              Container(width: 12, height: 12, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3))),
                              const SizedBox(width: 8),
                              Expanded(child: Text(e.key, style: const TextStyle(fontSize: 13))),
                              Text('${pct.toStringAsFixed(1)}%', style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
                              const SizedBox(width: 8),
                              Text(fmt.format(e.value), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
              ],

              // Bar Chart
              const Text('Monthly Trend', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                height: 220,
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
                ),
                child: monthlyData.isEmpty
                    ? Center(child: Text('No data', style: TextStyle(color: Colors.grey.shade400)))
                    : BarChart(
                        BarChartData(
                          barGroups: monthlyData.asMap().entries.map((e) {
                            return BarChartGroupData(
                              x: e.key,
                              barRods: [
                                BarChartRodData(toY: e.value['income']!, color: AppTheme.income, width: 10, borderRadius: BorderRadius.circular(4)),
                                BarChartRodData(toY: e.value['expense']!, color: AppTheme.expense, width: 10, borderRadius: BorderRadius.circular(4)),
                              ],
                            );
                          }).toList(),
                          titlesData: FlTitlesData(
                            bottomTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                getTitlesWidget: (value, meta) {
                                  final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                                  final now = DateTime.now();
                                  final monthIdx = (now.month - 5 + value.toInt()) % 12;
                                  return Text(months[monthIdx.clamp(0, 11)], style: const TextStyle(fontSize: 10));
                                },
                              ),
                            ),
                            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          ),
                          gridData: const FlGridData(show: false),
                          borderData: FlBorderData(show: false),
                        ),
                      ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _legend('Income', AppTheme.income),
                  const SizedBox(width: 16),
                  _legend('Expense', AppTheme.expense),
                ],
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  Widget _legend(String label, Color color) {
    return Row(
      children: [
        Container(width: 14, height: 14, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3))),
        const SizedBox(width: 6),
        Text(label, style: const TextStyle(fontSize: 13)),
      ],
    );
  }

  Widget _buildSummarySection(AppProvider provider, NumberFormat fmt) {
    final income = provider.monthlySummary['income'] ?? 0;
    final expense = provider.monthlySummary['expense'] ?? 0;
    final savings = income - expense;
    return Row(
      children: [
        Expanded(child: _statCard('Income', fmt.format(income), Icons.trending_up, AppTheme.income)),
        const SizedBox(width: 8),
        Expanded(child: _statCard('Expense', fmt.format(expense), Icons.trending_down, AppTheme.expense)),
        const SizedBox(width: 8),
        Expanded(child: _statCard('Savings', fmt.format(savings), Icons.savings, savings >= 0 ? AppTheme.primary : AppTheme.expense)),
      ],
    );
  }

  Widget _statCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13)),
          Text(label, style: const TextStyle(color: AppTheme.textGrey, fontSize: 10)),
        ],
      ),
    );
  }

  List<Map<String, double>> _getMonthlyData(List<ExpenseTransaction> txns) {
    final now = DateTime.now();
    return List.generate(6, (i) {
      final month = DateTime(now.year, now.month - 5 + i);
      final monthTxns = txns.where((t) => t.date.year == month.year && t.date.month == month.month);
      return {
        'income': monthTxns.where((t) => t.type == 'income').fold(0.0, (s, t) => s + t.amount),
        'expense': monthTxns.where((t) => t.type == 'expense').fold(0.0, (s, t) => s + t.amount),
      };
    });
  }
}
