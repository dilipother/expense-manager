import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/transaction_model.dart';
import '../models/bank_account_model.dart';
import '../models/cash_model.dart';

class AppProvider extends ChangeNotifier {
  List<BankAccount> _accounts = [];
  List<ExpenseTransaction> _transactions = [];
  List<CashEntry> _cashEntries = [];
  double _cashOnHand = 0.0;
  Map<String, double> _monthlySummary = {'income': 0, 'expense': 0};
  bool _isLoading = false;
  int _smsCount = 0;

  List<BankAccount> get accounts => _accounts;
  List<ExpenseTransaction> get transactions => _transactions;
  List<CashEntry> get cashEntries => _cashEntries;
  double get cashOnHand => _cashOnHand;
  Map<String, double> get monthlySummary => _monthlySummary;
  bool get isLoading => _isLoading;
  int get smsCount => _smsCount;

  double get totalBankBalance => _accounts
      .where((a) => !a.isCreditCard)
      .fold(0.0, (sum, a) => sum + a.balance);

  double get totalCreditUsed => _accounts
      .where((a) => a.isCreditCard)
      .fold(0.0, (sum, a) => sum + a.balance.abs());

  double get netWorth => totalBankBalance + _cashOnHand - totalCreditUsed;

  Future<void> loadAll() async {
    _isLoading = true;
    notifyListeners();
    final db = DatabaseHelper.instance;
    _accounts = await db.getBankAccounts();
    _transactions = await db.getAllTransactions();
    _cashEntries = await db.getCashEntries();
    _cashOnHand = await db.getCashOnHand();
    _monthlySummary = await db.getMonthlySummary();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> addAccount(BankAccount account) async {
    final db = DatabaseHelper.instance;
    await db.insertBankAccount(account);
    await loadAll();
  }

  Future<void> updateAccount(BankAccount account) async {
    final db = DatabaseHelper.instance;
    await db.updateBankAccount(account);
    await loadAll();
  }

  Future<void> deleteAccount(int id) async {
    final db = DatabaseHelper.instance;
    await db.deleteBankAccount(id);
    await loadAll();
  }

  Future<void> addTransaction(ExpenseTransaction txn) async {
    final db = DatabaseHelper.instance;
    await db.insertTransaction(txn);
    await loadAll();
  }

  Future<void> deleteTransaction(int id) async {
    final db = DatabaseHelper.instance;
    await db.deleteTransaction(id);
    await loadAll();
  }

  Future<void> addCashEntry(CashEntry entry) async {
    final db = DatabaseHelper.instance;
    await db.insertCashEntry(entry);
    await loadAll();
  }

  void setSmsCount(int count) {
    _smsCount = count;
    notifyListeners();
  }

  List<ExpenseTransaction> getTransactionsByAccount(int accountId) {
    return _transactions.where((t) => t.accountId == accountId).toList();
  }

  List<ExpenseTransaction> getRecentTransactions({int limit = 10}) {
    final sorted = List<ExpenseTransaction>.from(_transactions)
      ..sort((a, b) => b.date.compareTo(a.date));
    return sorted.take(limit).toList();
  }
}
