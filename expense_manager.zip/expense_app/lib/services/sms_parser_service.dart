import '../models/transaction_model.dart';
import '../models/bank_account_model.dart';
import '../database/database_helper.dart';

class SmsParserService {
  static final SmsParserService instance = SmsParserService._init();
  SmsParserService._init();

  // Known bank SMS sender IDs
  static const List<String> bankSenders = [
    'HDFCBK', 'HDFC', 'ICICIBK', 'ICICI', 'SBIMSG', 'SBI', 'AXISBK',
    'AXIS', 'KOTAKB', 'KOTAK', 'PNBSMS', 'PNB', 'BOBTXN', 'BOB',
    'CANBNK', 'CANARA', 'YESBK', 'INDBNK', 'PAYTM', 'PHONEPE',
    'CBSSBI', 'UNIONB', 'IDFCBK',
  ];

  bool isBankSms(String sender) {
    final upper = sender.toUpperCase();
    return bankSenders.any((s) => upper.contains(s));
  }

  ParsedTransaction? parseSms(String sender, String body, String smsId) {
    if (!isBankSms(sender)) return null;

    final bodyLower = body.toLowerCase();

    // Check if it's a debit or credit
    bool isDebit = bodyLower.contains('debited') ||
        bodyLower.contains('debit') ||
        bodyLower.contains('withdrawn') ||
        bodyLower.contains('sent') ||
        bodyLower.contains('paid') ||
        bodyLower.contains('purchase') ||
        bodyLower.contains('payment of');

    bool isCredit = bodyLower.contains('credited') ||
        bodyLower.contains('credit') ||
        bodyLower.contains('received') ||
        bodyLower.contains('deposited');

    if (!isDebit && !isCredit) return null;

    // Extract amount
    double? amount = _extractAmount(body);
    if (amount == null) return null;

    // Extract account number
    String? accountNum = _extractAccountNumber(body);

    // Extract merchant
    String? merchant = _extractMerchant(body);

    // Extract bank name from sender
    String bankName = _getBankFromSender(sender);

    // Determine category
    String category = _categorizeTransaction(body, merchant);

    return ParsedTransaction(
      smsId: smsId,
      amount: amount,
      type: isDebit ? 'expense' : 'income',
      bankName: bankName,
      accountNumber: accountNum ?? 'Unknown',
      merchantName: merchant,
      category: category,
      originalSms: body,
      date: DateTime.now(),
    );
  }

  double? _extractAmount(String body) {
    // Patterns: Rs.1234, INR 1234, Rs 1,234.50, ₹1234
    final patterns = [
      RegExp(r'(?:rs\.?|inr|₹)\s*([0-9,]+(?:\.[0-9]{1,2})?)', caseSensitive: false),
      RegExp(r'([0-9,]+(?:\.[0-9]{1,2})?)\s*(?:rs\.?|inr|₹)', caseSensitive: false),
    ];

    for (final pattern in patterns) {
      final match = pattern.firstMatch(body);
      if (match != null) {
        final amtStr = match.group(1)!.replaceAll(',', '');
        return double.tryParse(amtStr);
      }
    }
    return null;
  }

  String? _extractAccountNumber(String body) {
    final patterns = [
      RegExp(r'(?:a\/c|account|acct|card)[\s#:]*(?:no\.?\s*)?([xX*]{2,}[0-9]{4})', caseSensitive: false),
      RegExp(r'([xX*]{3,}[0-9]{4})'),
      RegExp(r'ending\s+(?:with\s+)?([0-9]{4})'),
    ];

    for (final pattern in patterns) {
      final match = pattern.firstMatch(body);
      if (match != null) return match.group(1);
    }
    return null;
  }

  String? _extractMerchant(String body) {
    final patterns = [
      RegExp(r'at\s+([A-Z][A-Za-z0-9\s&\-\.]{2,30}?)(?:\s+on|\s+for|\s+via|\.)', caseSensitive: false),
      RegExp(r'to\s+([A-Z][A-Za-z0-9\s&\-\.]{2,25}?)(?:\s+on|\s+for|\s*\.|$)', caseSensitive: false),
      RegExp(r'merchant[:\s]+([A-Za-z0-9\s&\-\.]{2,25})', caseSensitive: false),
    ];

    for (final pattern in patterns) {
      final match = pattern.firstMatch(body);
      if (match != null) {
        final merchant = match.group(1)?.trim();
        if (merchant != null && merchant.length > 2) return merchant;
      }
    }
    return null;
  }

  String _getBankFromSender(String sender) {
    final upper = sender.toUpperCase();
    if (upper.contains('HDFC')) return 'HDFC Bank';
    if (upper.contains('ICICI')) return 'ICICI Bank';
    if (upper.contains('SBI') || upper.contains('CBS')) return 'SBI';
    if (upper.contains('AXIS')) return 'Axis Bank';
    if (upper.contains('KOTAK')) return 'Kotak Mahindra';
    if (upper.contains('PNB')) return 'Punjab National Bank';
    if (upper.contains('BOB')) return 'Bank of Baroda';
    if (upper.contains('CAN')) return 'Canara Bank';
    if (upper.contains('YES')) return 'Yes Bank';
    if (upper.contains('PAYTM')) return 'Paytm';
    if (upper.contains('PHONE')) return 'PhonePe';
    if (upper.contains('IDFC')) return 'IDFC First Bank';
    return 'Bank';
  }

  String _categorizeTransaction(String body, String? merchant) {
    final text = '${body.toLowerCase()} ${merchant?.toLowerCase() ?? ''}';

    if (text.contains('swiggy') || text.contains('zomato') || text.contains('food') || text.contains('restaurant') || text.contains('cafe') || text.contains('hotel')) {
      return 'Food & Dining';
    }
    if (text.contains('amazon') || text.contains('flipkart') || text.contains('myntra') || text.contains('shopping') || text.contains('mall')) {
      return 'Shopping';
    }
    if (text.contains('uber') || text.contains('ola') || text.contains('petrol') || text.contains('fuel') || text.contains('metro') || text.contains('irctc')) {
      return 'Transport';
    }
    if (text.contains('electricity') || text.contains('water') || text.contains('gas') || text.contains('internet') || text.contains('mobile') || text.contains('recharge')) {
      return 'Bills & Utilities';
    }
    if (text.contains('netflix') || text.contains('hotstar') || text.contains('prime') || text.contains('cinema') || text.contains('movie')) {
      return 'Entertainment';
    }
    if (text.contains('hospital') || text.contains('pharmacy') || text.contains('medical') || text.contains('health') || text.contains('doctor')) {
      return 'Health & Fitness';
    }
    if (text.contains('salary') || text.contains('payroll') || text.contains('neft credit')) {
      return 'Salary';
    }
    return 'Others';
  }

  Future<List<ExpenseTransaction>> processSmsMessages(List<Map<String, String>> messages, List<BankAccount> accounts) async {
    final db = DatabaseHelper.instance;
    final List<ExpenseTransaction> newTransactions = [];

    for (final msg in messages) {
      final smsId = msg['id'] ?? '';
      if (await db.isSmsProcessed(smsId)) continue;

      final parsed = parseSms(msg['sender'] ?? '', msg['body'] ?? '', smsId);
      if (parsed == null) continue;

      // Find matching account
      int? accountId;
      for (final account in accounts) {
        if (account.bankName.toLowerCase().contains(parsed.bankName.toLowerCase()) ||
            (parsed.accountNumber.length >= 4 &&
                account.accountNumber.endsWith(parsed.accountNumber.substring(parsed.accountNumber.length - 4)))) {
          accountId = account.id;
          break;
        }
      }

      final txn = ExpenseTransaction(
        title: parsed.merchantName ?? parsed.bankName,
        amount: parsed.amount,
        type: parsed.type,
        category: parsed.category,
        accountId: accountId,
        isCash: false,
        note: 'From SMS',
        date: parsed.date,
        smsSource: parsed.originalSms,
        merchantName: parsed.merchantName,
      );

      await db.insertTransaction(txn);
      await db.markSmsProcessed(smsId);
      newTransactions.add(txn);
    }

    return newTransactions;
  }
}

class ParsedTransaction {
  final String smsId;
  final double amount;
  final String type;
  final String bankName;
  final String accountNumber;
  final String? merchantName;
  final String category;
  final String originalSms;
  final DateTime date;

  ParsedTransaction({
    required this.smsId,
    required this.amount,
    required this.type,
    required this.bankName,
    required this.accountNumber,
    this.merchantName,
    required this.category,
    required this.originalSms,
    required this.date,
  });
}
