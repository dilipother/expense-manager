class ExpenseTransaction {
  final int? id;
  final String title;
  final double amount;
  final String type; // 'income' or 'expense'
  final String category;
  final int? accountId;
  final bool isCash;
  final String? note;
  final DateTime date;
  final String? smsSource;
  final String? merchantName;
  final DateTime createdAt;

  ExpenseTransaction({
    this.id,
    required this.title,
    required this.amount,
    required this.type,
    required this.category,
    this.accountId,
    this.isCash = false,
    this.note,
    required this.date,
    this.smsSource,
    this.merchantName,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'amount': amount,
      'type': type,
      'category': category,
      'accountId': accountId,
      'isCash': isCash ? 1 : 0,
      'note': note,
      'date': date.toIso8601String(),
      'smsSource': smsSource,
      'merchantName': merchantName,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory ExpenseTransaction.fromMap(Map<String, dynamic> map) {
    return ExpenseTransaction(
      id: map['id'],
      title: map['title'],
      amount: map['amount'],
      type: map['type'],
      category: map['category'],
      accountId: map['accountId'],
      isCash: map['isCash'] == 1,
      note: map['note'],
      date: DateTime.parse(map['date']),
      smsSource: map['smsSource'],
      merchantName: map['merchantName'],
      createdAt: DateTime.parse(map['createdAt']),
    );
  }

  ExpenseTransaction copyWith({
    int? id,
    String? title,
    double? amount,
    String? type,
    String? category,
    int? accountId,
    bool? isCash,
    String? note,
    DateTime? date,
  }) {
    return ExpenseTransaction(
      id: id ?? this.id,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      type: type ?? this.type,
      category: category ?? this.category,
      accountId: accountId ?? this.accountId,
      isCash: isCash ?? this.isCash,
      note: note ?? this.note,
      date: date ?? this.date,
      smsSource: smsSource,
      merchantName: merchantName,
      createdAt: createdAt,
    );
  }
}

const List<String> expenseCategories = [
  'Food & Dining',
  'Shopping',
  'Transport',
  'Bills & Utilities',
  'Entertainment',
  'Health & Fitness',
  'Travel',
  'Education',
  'Personal Care',
  'Others',
];

const List<String> incomeCategories = [
  'Salary',
  'Freelance',
  'Investment',
  'Gift',
  'Rental',
  'Business',
  'Others',
];
