import 'package:flutter/material.dart';

class BankAccount {
  final int? id;
  final String bankName;
  final String accountNumber;
  final String accountType; // Savings, Current, Credit Card
  double balance;
  final int color;
  final DateTime createdAt;

  BankAccount({
    this.id,
    required this.bankName,
    required this.accountNumber,
    required this.accountType,
    required this.balance,
    required this.color,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Color get colorValue => Color(color);

  bool get isCreditCard => accountType == 'Credit Card';

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'bankName': bankName,
      'accountNumber': accountNumber,
      'accountType': accountType,
      'balance': balance,
      'color': color,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory BankAccount.fromMap(Map<String, dynamic> map) {
    return BankAccount(
      id: map['id'],
      bankName: map['bankName'],
      accountNumber: map['accountNumber'],
      accountType: map['accountType'],
      balance: map['balance'],
      color: map['color'],
      createdAt: DateTime.parse(map['createdAt']),
    );
  }

  BankAccount copyWith({
    String? bankName,
    String? accountNumber,
    String? accountType,
    double? balance,
    int? color,
  }) {
    return BankAccount(
      id: id,
      bankName: bankName ?? this.bankName,
      accountNumber: accountNumber ?? this.accountNumber,
      accountType: accountType ?? this.accountType,
      balance: balance ?? this.balance,
      color: color ?? this.color,
      createdAt: createdAt,
    );
  }

  String get bankInitials {
    final words = bankName.split(' ');
    if (words.length >= 2) {
      return words[0][0].toUpperCase() + words[1][0].toUpperCase();
    }
    return bankName.substring(0, 2).toUpperCase();
  }

  String get maskedAccount {
    if (accountNumber.length > 4) {
      return '••••${accountNumber.substring(accountNumber.length - 4)}';
    }
    return accountNumber;
  }
}

const List<String> accountTypes = ['Savings', 'Current', 'Credit Card'];

const List<String> popularBanks = [
  'HDFC Bank',
  'ICICI Bank',
  'SBI',
  'Axis Bank',
  'Kotak Mahindra',
  'Punjab National Bank',
  'Bank of Baroda',
  'Canara Bank',
  'Yes Bank',
  'IndusInd Bank',
  'Other',
];
