class CashEntry {
  final int? id;
  final String type; // 'add', 'atm_withdraw', 'spend'
  final double amount;
  final String? description;
  final DateTime date;
  final DateTime createdAt;

  CashEntry({
    this.id,
    required this.type,
    required this.amount,
    this.description,
    required this.date,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  bool get isInflow => type == 'add' || type == 'atm_withdraw';

  String get typeLabel {
    switch (type) {
      case 'add':
        return 'Cash Added';
      case 'atm_withdraw':
        return 'ATM Withdrawal';
      case 'spend':
        return 'Cash Spent';
      default:
        return 'Cash';
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'type': type,
      'amount': amount,
      'description': description,
      'date': date.toIso8601String(),
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory CashEntry.fromMap(Map<String, dynamic> map) {
    return CashEntry(
      id: map['id'],
      type: map['type'],
      amount: map['amount'],
      description: map['description'],
      date: DateTime.parse(map['date']),
      createdAt: DateTime.parse(map['createdAt']),
    );
  }
}
