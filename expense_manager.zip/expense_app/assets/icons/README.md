# Place your icon assets here (PNG or SVG).
# The app uses Flutter's built-in Material Icons for all UI icons,
# so this folder is only needed if you want custom brand icons.
