# Place your image assets here.
# Recommended free sources:
#   https://undraw.co        (SVG/PNG illustrations, no attribution required)
#   https://www.flaticon.com (icons, free tier available)
#   https://icons8.com       (icons & illustrations)
#
# Suggested files to add:
#   wallet.png       — cash wallet illustration
#   no_data.png      — empty state illustration
#   bank.png         — generic bank illustration
#   success.png      — success tick animation
