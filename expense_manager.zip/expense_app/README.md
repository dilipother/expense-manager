# 💰 Expense Manager — Flutter App

A full-featured personal finance tracker for iOS and Android, built with Flutter.  
Tracks income, expenses, bank accounts, credit cards, and cash — and can auto-import transactions by reading bank SMS messages (Android).

---

## ✨ Features

| Feature | Description |
|---|---|
| 🏦 Bank Accounts | Add multiple savings, current, and credit card accounts with live balances |
| 💵 Cash Wallet | Track cash on hand; log ATM withdrawals and cash spends |
| 📲 SMS Import | Reads bank SMS on Android and auto-parses transactions (demo mode on iOS) |
| 📊 Analytics | Pie chart by category + monthly income/expense bar chart |
| 🎯 Budget Tracker | Set per-category monthly budgets with live progress bars |
| 🔄 Transfers | Move money between bank accounts or cash with a clean flow UI |
| 🔍 Transaction History | Filter by All / Income / Expense / Cash; swipe to delete |
| 🏠 Home Dashboard | Net worth, cash on hand, bank card carousel, recent transactions |
| ⚙️ Settings | Budget, SMS import, transfer, app lock (Face ID), export to CSV |

---

## 📁 Project Structure

```
expense_manager/
│
├── android/                        Android-specific config
│   ├── app/
│   │   ├── build.gradle
│   │   └── src/main/
│   │       ├── AndroidManifest.xml (SMS, camera, notification perms)
│   │       ├── kotlin/…/
│   │       │   ├── MainActivity.kt
│   │       │   └── SmsReceiver.kt  ← Real-time SMS broadcast receiver
│   │       └── res/
│   └── build.gradle
│
├── ios/                            iOS-specific config
│   ├── Podfile                     CocoaPods, platform iOS 13.0
│   ├── Flutter/
│   │   ├── Debug.xcconfig
│   │   └── Release.xcconfig
│   ├── Runner.xcodeproj/
│   │   ├── project.pbxproj
│   │   └── xcshareddata/xcschemes/Runner.xcscheme
│   ├── Runner.xcworkspace/
│   │   └── contents.xcworkspacedata
│   └── Runner/
│       ├── Info.plist              Permissions: Face ID, camera, photos, notifications
│       ├── AppDelegate.swift
│       ├── Base.lproj/
│       │   ├── LaunchScreen.storyboard  (purple branded)
│       │   └── Main.storyboard
│       └── Assets.xcassets/
│
├── lib/
│   ├── main.dart                   Entry point + animated splash screen
│   │
│   ├── models/
│   │   ├── transaction_model.dart  ExpenseTransaction, category lists
│   │   ├── bank_account_model.dart BankAccount, popular banks, account types
│   │   └── cash_model.dart         CashEntry (add / atm_withdraw / spend)
│   │
│   ├── database/
│   │   └── database_helper.dart    SQLite via sqflite — all CRUD + summary queries
│   │
│   ├── services/
│   │   ├── app_provider.dart       ChangeNotifier state management
│   │   └── sms_parser_service.dart Regex-based SMS parser for 15+ Indian banks
│   │
│   ├── screens/
│   │   ├── home_screen.dart        Dashboard + bottom nav + speed-dial FAB
│   │   ├── add_transaction_screen.dart
│   │   ├── add_account_screen.dart
│   │   ├── all_transactions_screen.dart
│   │   ├── account_detail_screen.dart
│   │   ├── cash_screen.dart
│   │   ├── transfer_screen.dart    ← Transfer between accounts / cash
│   │   ├── analytics_screen.dart   fl_chart pie + bar chart
│   │   ├── budget_screen.dart      Per-category budget tracker
│   │   ├── sms_import_screen.dart  SMS scan + import flow
│   │   └── settings_screen.dart
│   │
│   ├── widgets/
│   │   └── common_widgets.dart     TransactionTile, EmptyState, GradientButton, …
│   │
│   └── utils/
│       ├── app_theme.dart          ThemeData, colour palette, category maps
│       ├── formatters.dart         Currency, date, compact (₹1.2L) formatters
│       └── validators.dart         Form field validators
│
├── assets/
│   ├── images/   (add your own PNG illustrations here)
│   └── icons/    (add custom brand icons here)
│
├── pubspec.yaml
├── .gitignore
└── README.md
```

---

## 🚀 Getting Started

### Prerequisites

- Flutter SDK ≥ 3.0.0  — [install guide](https://docs.flutter.dev/get-started/install)
- Xcode ≥ 14 (for iOS builds)
- CocoaPods — `sudo gem install cocoapods`
- Android Studio / VS Code with Flutter plugin

### 1 — Clone & install dependencies

```bash
git clone <your-repo-url>
cd expense_manager
flutter pub get
```

### 2 — iOS setup

```bash
cd ios
pod install
cd ..
flutter run
```

Open `ios/Runner.xcworkspace` (not `.xcodeproj`) in Xcode to adjust signing / bundle ID if needed.

### 3 — Android setup

```bash
flutter run
```

No extra steps — gradle downloads dependencies automatically.

---

## 🗄️ Database Schema

All data is stored locally using **SQLite via sqflite**. The DB file is `expense_manager.db`.

```sql
bank_accounts  (id, bankName, accountNumber, accountType, balance, color, createdAt)
transactions   (id, title, amount, type, category, accountId, isCash, note, date, smsSource, merchantName, createdAt)
cash_entries   (id, type, amount, description, date, createdAt)
sms_processed  (id, smsId, processedAt)   ← deduplication log
```

Three sample bank accounts are pre-seeded on first launch so the UI is immediately populated.

---

## 📲 SMS Import

### Android
The app requests `READ_SMS` permission at runtime. It scans the SMS inbox for messages from known bank sender IDs (HDFCBK, ICICIBK, SBIMSG, AXISBK, etc.) and parses:

- **Amount** — `Rs.1234`, `INR 1,234.50`, `₹500`
- **Type** — debited / credited / withdrawn / received
- **Account number** — last 4 digits
- **Merchant** — extracted from `at <merchant>` or `to <payee>` patterns
- **Category** — auto-assigned based on merchant name (Swiggy→Food, Amazon→Shopping, etc.)

Parsed transactions are linked to matching saved accounts and saved to the DB. Already-processed SMS are tracked to avoid duplicates.

### iOS
iOS does not allow third-party apps to read SMS. The SMS Import screen runs in **demo/simulation mode** on iOS — it demonstrates the parsing flow using realistic mock data.

---

## 🎨 Design System

| Token | Value |
|---|---|
| Primary | `#6C63FF` (violet) |
| Secondary | `#FF6584` (pink) |
| Accent | `#43B89C` (teal) |
| Cash / Orange | `#FF9F43` |
| Income | `#00B894` |
| Expense | `#FF6584` |
| Background | `#F5F6FA` |

All colours are defined in `lib/utils/app_theme.dart`.

---

## 📦 Dependencies

| Package | Purpose |
|---|---|
| `sqflite` | SQLite local database |
| `path` | DB file path resolution |
| `provider` | Lightweight state management |
| `fl_chart` | Pie & bar charts |
| `intl` | Currency & date formatting |
| `flutter_slidable` | Swipe-to-delete on list items |
| `permission_handler` | Runtime permission requests |
| `cupertino_icons` | iOS-style icons |

---

## 🔮 Roadmap / Future Enhancements

- [ ] Cloud sync (Firebase / Supabase)
- [ ] Recurring transactions
- [ ] Export to CSV / PDF
- [ ] Multiple currencies
- [ ] Dark mode
- [ ] Widgets (home screen balance widget)
- [ ] Real-time SMS auto-import on Android (background service)
- [ ] UPI transaction deep-link parsing
- [ ] Investment portfolio tracker

---

## 📄 License

MIT — free to use, modify, and distribute.
