package com.expensemanager.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log

/**
 * SmsReceiver — listens for incoming SMS in real-time.
 * When a bank SMS is received while the app is running, it triggers
 * the Flutter side to re-scan and auto-import the transaction.
 *
 * The actual parsing is done in Dart (SmsParserService).
 * This receiver simply notifies Flutter via a local broadcast or
 * shared preferences flag that a new SMS arrived.
 */
class SmsReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "ExpenseSmsReceiver"
        private const val PREFS_NAME = "expense_manager_prefs"
        private const val KEY_NEW_SMS = "new_bank_sms_arrived"

        // Bank sender ID prefixes to watch
        private val BANK_SENDERS = setOf(
            "HDFCBK", "HDFC", "ICICIBK", "ICICI",
            "SBIMSG", "SBI", "AXISBK", "AXIS",
            "KOTAKB", "KOTAK", "PNBSMS", "PNB",
            "BOBTXN", "BOB", "CANBNK", "CANARA",
            "YESBK", "INDBNK", "PAYTM", "PHONEPE",
            "CBSSBI", "IDFCBK"
        )
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        for (message in messages) {
            val sender = message.originatingAddress?.uppercase() ?: continue
            val body = message.messageBody ?: continue

            val isBankSms = BANK_SENDERS.any { sender.contains(it) }
            if (!isBankSms) continue

            Log.d(TAG, "Bank SMS received from: $sender")

            // Set a flag in SharedPreferences for Flutter to pick up on next resume
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putBoolean(KEY_NEW_SMS, true)
                .putString("last_bank_sms_sender", sender)
                .putString("last_bank_sms_body", body)
                .apply()
        }
    }
}
